"""Local operations; every command executes a real transformation or check."""

from __future__ import annotations

import asyncio
import json
import shutil
import sqlite3
from contextlib import closing
from pathlib import Path

import typer

from .settings import load_environment
from .storage import Store, atomic_json, now

load_environment()

app = typer.Typer(no_args_is_help=True, help="FPL Intelligence · free local numerical decision tools")


def show(value):
    typer.echo(json.dumps(value, indent=2, default=str))


@app.command()
def maintain_models():
    """Remove retired weights and refit companions against supported feature contracts."""
    from .maintenance import maintain_models as run

    show(run(Store()))


@app.command()
def train_role_minutes():
    """Validate and fit the non-neural immediate participation expert."""
    from .role_minutes import attach, train, validate

    store = Store()
    show(validate(store))
    show(train(store))
    if store.list("decision_model", 1):
        show({"decision_model_id": attach(store, store.get("decision_model"))["id"]})


@app.command()
def doctor():
    """Check local state integrity, source freshness, installed versions and free-cost policy."""
    import importlib.metadata

    from .ingestion import freshness

    store = Store()
    with store.db() as db:
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
    result = {
        "at": now(),
        "database_integrity": integrity,
        "data_dir": str(store.root.resolve()),
        "paid_provider_calls_allowed": False,
        "local_llm": False,
        "versions": {
            name: importlib.metadata.version(name) for name in ("numpy", "highspy", "fastapi", "lightgbm")
        },
    }
    for source in ("bootstrap", "fixtures"):
        try:
            _, meta = store.latest(source)
            result[source] = {"age_hours": freshness(meta), "hash": meta["hash"]}
        except ValueError:
            result[source] = "not yet ingested"
    show(result)


@app.command("audit-scoring")
def audit_scoring():
    """Compare form/statistics and online-bias candidates without changing production."""
    from threadpoolctl import threadpool_limits

    from .immediate_points import validate
    from .online_calibration import validate as validate_bias

    store = Store()
    before = store.get("decision_model")["id"]
    with threadpool_limits(limits=1):
        points = validate(store)
        bias = validate_bias(store)
    assert store.get("decision_model")["id"] == before
    show({"statistics": points, "online_bias": bias, "production_model_unchanged": True})


@app.command("audit-inputs")
def audit_inputs():
    """Check the active historical/live feature contract without changing the account."""
    from .role_minutes import audit_input_contract

    show(audit_input_contract(Store()))


@app.command()
def ingest(entry: int = 9375678, league: int = 1873551, histories: bool = True):
    """Refresh official sources and optional public comparator with raw provenance."""
    from .ingestion import Official

    show(asyncio.run(Official(Store()).ingest(entry=entry, league=league, histories=histories)))


@app.command()
def snapshot(destination: Path = Path("artifacts/runtime/snapshot-manifest.json")):
    """Freeze the current source manifest without altering any raw snapshots."""
    store = Store()
    with store.db() as db:
        records = [dict(r) for r in db.execute("SELECT * FROM snapshots ORDER BY id")]
    body = {"created_at": now(), "snapshots": records}
    atomic_json(destination, body)
    show({"path": str(destination), "count": len(records)})


@app.command("reconcile-team")
def reconcile_team(path: Path = Path("research/04_USER_CONTEXT.json"), confirmed: bool = False):
    """Import the dated seed or a structured exact account export; validate money and identity."""
    from .domain import TeamState
    from .ingestion import load_market, reconcile_seed
    from .rules import Rules, validate_squad

    store = Store()
    body = json.loads(path.read_text())
    if "team" in body:
        state = reconcile_seed(store, body)
        if confirmed:
            raise typer.BadParameter(
                "Dated research seed cannot be marked confirmed; import an exact current state"
            )
    else:
        parsed_state = TeamState.model_validate({k: v for k, v in body.items() if k != "id"})
        if confirmed:
            parsed_state.status = "confirmed"
        players, _ = load_market(store)
        validate_squad(parsed_state, players, Rules.from_bootstrap(store.latest("bootstrap")[0]))
        identity = store.put("state", parsed_state.model_dump())
        store.event("account_import", identity, {"path": str(path), "status": parsed_state.status})
        state = parsed_state.model_dump() | {"id": identity}
    show(
        {
            "state_id": state["id"],
            "status": state["status"],
            "bank": state["bank"],
            "selling_value": sum(lot["sell_price"] for lot in state["lots"]),
        }
    )


@app.command("build-features")
def build_features():
    from .features import build_features as build
    from .ingestion import load_market

    store = Store()
    players, market = load_market(store)
    show(build(store, players, market))


@app.command()
def train(legacy: bool = False):
    """Train the actual decision forecaster; --legacy reproduces the old shadow benchmark."""
    if legacy:
        from .evaluation import train_evaluate

        result = train_evaluate(Store())
    else:
        from threadpoolctl import threadpool_limits

        from .decision import train_decisions

        store = Store()
        active = store.get("decision_model") if store.list("decision_model", 1) else {}
        with threadpool_limits(limits=1):
            if active.get("fusion_model_id"):
                from .context_archive import import_context
                from .fusion import refit_active_fusion

                asyncio.run(import_context(store))
                result = refit_active_fusion(store)
            else:
                result = train_decisions(store)
            from .role_minutes import ensure

            result = ensure(store, result)
    show({k: v for k, v in result.items() if k not in ("predictions", "residuals", "curves")})


@app.command("uncertainty-audit")
def uncertainty_audit():
    from threadpoolctl import threadpool_limits

    from .decision import validate_uncertainty

    with threadpool_limits(limits=1):
        show(validate_uncertainty(Store()))


@app.command("manager-benchmark")
def manager_benchmark():
    from .manager_audit import benchmark_managers

    result = asyncio.run(benchmark_managers(Store()))
    show({k: v for k, v in result.items() if k not in ("comparisons", "errors")})


@app.command("train-components")
def train_components():
    """Chronologically train/calibrate minutes and test dynamic team strengths."""
    from .models import fit_ensemble, fit_model_suite
    from .strength import train_strength

    store = Store()
    minutes = fit_model_suite(store)
    strength = train_strength(store)
    ensemble = fit_ensemble(store)
    show(
        {
            "minutes_model_id": minutes["id"],
            "minutes_promoted": minutes["promoted"],
            "strength_model_id": strength["id"],
            "strength_promoted": strength["promoted"],
            "ensemble_promoted": ensemble["promoted"],
        }
    )


@app.command("open-benchmark")
def open_benchmark():
    """Reproduce hash-pinned Dastan outputs and the released historical OpenFPL benchmark."""
    from .open_models import reproduce

    show(reproduce(Store()))


@app.command("policy-replay")
def policy_replay():
    """Replay the out-of-fold production model through a continuously evolving account."""
    from .decision_audit import replay_policy

    result = replay_policy(Store())
    show(
        {
            **result,
            "policies": {
                name: {k: v for k, v in row.items() if k != "ledger"}
                for name, row in result["policies"].items()
            },
        }
    )


@app.command("decision-audit")
def decision_audit():
    """Compare held-out captains and budgeted teams with honest hindsight diagnostics."""
    from .decision_audit import evaluate_choices

    result = evaluate_choices(Store())
    show({k: v for k, v in result.items() if k not in ("weeks", "captains")})


@app.command("research-refresh")
def refresh_research(benchmark: bool = False):
    """Refresh original-source evidence or benchmark eligible free hosted extractors."""
    from .context import benchmark_extraction, research_refresh

    store = Store()
    show(asyncio.run(benchmark_extraction(store) if benchmark else research_refresh(store)))


@app.command("configure-providers")
def configure_providers(unbilled: bool = False):
    """Verify each optional free provider independently without printing credentials."""
    from .providers import configure

    show(configure(Store(), unbilled))


@app.command("sources-refresh")
def sources_refresh():
    """Refresh verified prior-qualified managers, workload facts and public source leads."""
    from .intelligence import refresh_sources

    show(asyncio.run(refresh_sources(Store())))


@app.command("train-fusion")
def train_fusion():
    """Evaluate multi-source boosted trees on chronological held-out deadlines."""
    from .context_archive import import_context
    from .fusion import compare_live, review_fusion
    from .fusion import train_fusion as run

    store = Store()
    asyncio.run(import_context(store))
    result = run(store)
    review_fusion(store)
    compare_live(store)
    show({k: v for k, v in result.items() if k != "tree_spec"})


@app.command("train-decisions")
def train_decisions():
    """Train, calibrate and evaluate the points model that drives recommendations."""
    from threadpoolctl import threadpool_limits

    from .decision import train_decisions as run

    with threadpool_limits(limits=1):
        result = run(Store())
    show({k: v for k, v in result.items() if k not in ("predictions", "residuals", "curves")})


@app.command("scenario")
def scenario(path: Path, plan_id: str = ""):
    """Evaluate observable injury/role/fixture/price branches with an identical action prefix."""
    from .scenarios import ScenarioSpec, evaluate_scenarios

    store = Store()
    body = json.loads(path.read_text())
    show(
        evaluate_scenarios(
            store,
            plan_id or store.get("selected_plan")["plan_id"],
            [ScenarioSpec.model_validate(row) for row in body["scenarios"]],
        )
    )


@app.command("import-history")
def import_history(season: str = "2025-26"):
    """Import a free historical archive with season-scoped identities and statistical provenance."""
    from .history import import_season

    show(import_season(Store(), season))


@app.command("select-initial")
def select_initial(budget: int = 1000, event: int = 1, seconds: float = 15):
    """Select a legal initial/late-entry squad with all 15 players inside the supplied budget."""
    from .domain import Lot, TeamState
    from .ingestion import load_market
    from .optimization import select_squad
    from .rules import Rules, validate_squad

    store = Store()
    players, market = load_market(store)
    forecast = store.get("forecast")
    if not forecast["start_event"] <= event <= forecast["end_event"]:
        raise typer.BadParameter("Requested initial event is outside the frozen forecast")
    rules = Rules.from_bootstrap(store.latest("bootstrap")[0])
    means = {r["player_id"]: r["mean"] for r in forecast["players"] if r["event"] == event}
    picked = select_squad(None, players, rules, means, seconds, initial_budget=budget)
    state = TeamState(
        season=market["season"],
        event=event,
        bank=budget - sum(players[p].price for p in picked),
        free_transfers=1,
        lots=[
            Lot(
                player_id=p,
                purchase_price=players[p].price,
                sell_price=players[p].price,
                quote_market_price=players[p].price,
                provenance="initial_selection",
            )
            for p in picked
        ],
        initial=True,
        known_at=now(),
        status="public_deadline",
    )
    validate_squad(state, players, rules)
    identity = store.put("state", state.model_dump())
    show({"state_id": identity, "bank": state.bank, "squad": picked, "status": state.status})


@app.command()
def calibrate():
    """Measure held-out start-probability reliability in fixed bins."""
    import numpy as np

    store = Store()
    result = store.get("evaluation")
    rows = result["predictions"]
    bins = []
    for lo in np.arange(0, 1, 0.1):
        selected = [r for r in rows if lo <= r["prior_start"] < lo + 0.1]
        if selected:
            bins.append(
                {
                    "low": float(lo),
                    "high": float(lo + 0.1),
                    "n": len(selected),
                    "predicted": float(np.mean([r["prior_start"] for r in selected])),
                    "observed": float(np.mean([r["started"] for r in selected])),
                }
            )
    body = {
        "at": now(),
        "evaluation_id": result["id"],
        "kind": "held_out_reliability_diagnostic",
        "bins": bins,
        "applied_to_model": False,
    }
    body["id"] = store.put("calibration", body)
    show(body)


@app.command()
def forecast(end: int = 38, worlds: int = 4000, seed: int = 11, beliefs: bool = False):
    """Freeze complete player-fixture distributions in coherent shared match worlds."""
    from .simulation import forecast as run

    result = run(Store(), end_event=end, worlds=worlds, seed=seed, use_beliefs=beliefs)
    show({k: v for k, v in result.items() if k not in ("players", "fixtures", "match_audit", "player_ids")})


@app.command()
def research(
    url: str = "", claims: Path | None = None, belief: Path | None = None, capability: Path | None = None
):
    """Retrieve official source text, import supported claims, or extract using verified free hosted AI."""
    from .ingestion import load_market
    from .research import Belief, Claim, FreeCapability, extract, retrieve, save_claim

    store = Store()
    if belief:
        item = Belief.model_validate(json.loads(belief.read_text()))
        players, _ = load_market(store)
        if item.player_id not in players:
            raise typer.BadParameter("Unknown player")
        show({"belief_id": store.put("belief", item.model_dump())})
    elif claims:
        body = json.loads(claims.read_text())
        show(
            {
                "claim_ids": [
                    save_claim(store, Claim.model_validate(c), body["source_text"]) for c in body["claims"]
                ]
            }
        )
    elif url:
        source = asyncio.run(retrieve(store, url))
        if capability:
            players, _ = load_market(store)
            cap = FreeCapability.model_validate(json.loads(capability.read_text()))
            show(
                {
                    "claim_ids": asyncio.run(
                        extract(
                            store,
                            source,
                            cap,
                            [
                                {"id": p.id, "name": p.name}
                                for p in players.values()
                                if p.web_name.lower() in source["text"].lower()
                            ],
                        )
                    )
                }
            )
        else:
            show(source)
    else:
        show(
            {
                "claims": store.list("claim"),
                "beliefs": store.list("belief"),
                "hosted_inference": "Optional; verified free capability and account key required",
            }
        )


@app.command()
def simulate(plan_id: str = ""):
    """Rescore an actual plan with exact autosubs/captain fallback in frozen shared worlds."""
    from .simulation import score_plan

    store = Store()
    plan = store.get("plan", plan_id or None)
    score_plan(store, plan, store.get("forecast", plan["forecast_id"]))
    show(plan["simulation"])


@app.command()
def optimize(
    end: int = 19,
    seconds: float | None = None,
    state_id: str = "",
    forecast_id: str = "",
    chips: str = "auto",
    max_transfers: int = 15,
):
    """Joint full-market transfer/chip MIP with independent legality and scenario validation."""
    from .optimization import hold_plan
    from .optimization import optimize as run

    store = Store()
    state_id = state_id or store.get("state")["id"]
    forecast_id = forecast_id or store.get("forecast")["id"]
    fixed = None if chips == "auto" else {int(k): v for k, v in json.loads(chips).items()}
    from .search_control import search_session

    with search_session(unlimited=seconds is None):
        result = run(store, state_id, forecast_id, end, seconds, chips=fixed, max_transfers=max_transfers)
        hold = hold_plan(store, state_id, forecast_id, end)
        from .objectives import choose_recommendation

        result, _ = choose_recommendation(store, [result, hold], store.get("forecast", forecast_id))
        from .readiness import selection_is_current

        if selection_is_current(store, result):
            store.put("selected_plan", {"plan_id": result["id"], "at": now()})
        show(
            {
                "plan_id": result["id"],
                "solver": result["solver"],
                "simulation": result["simulation"],
                "hold": hold["simulation"],
                "execution_ready": result["execution_ready"],
            }
        )


@app.command()
def rivals(league: int = 1873551, entry: int = 9375678, case: bool = False, seconds: float = 30):
    """Retrieve actual mini-league membership and compare candidate policies in common worlds."""
    from .rivals import case_comparison, discover, effective_ownership

    store = Store()
    result = asyncio.run(discover(store, league, entry))
    if case:
        result = case_comparison(store, store.get("state")["id"], store.get("forecast")["id"], seconds)
    else:
        result["effective_ownership"] = effective_ownership(store, result)
    show(result)


@app.command()
def explain(plan_id: str = ""):
    """Render a numerical plan as a human-readable report without language-model invention."""
    from .reports import render

    store = Store()
    typer.echo(render(store, store.get("plan", plan_id or store.get("selected_plan")["plan_id"])))


@app.command()
def replay(plan_id: str = ""):
    """Independently replay every exported action against its frozen state and market."""
    from .domain import Action, Lineup, TeamState
    from .ingestion import load_market
    from .rules import Rules, transition

    store = Store()
    plan = store.get("plan", plan_id or store.get("selected_plan")["plan_id"])
    state = TeamState.model_validate(
        {k: v for k, v in store.get("state", plan["state_id"]).items() if k != "id"}
    )
    players, market = load_market(store, plan["market_id"])
    rules = Rules.from_bootstrap(store.latest("bootstrap", content_hash=market["source_hash"])[0])
    for row in plan["ledger"]:
        action = Action(
            sell=[r["player_id"] for r in row["sell"]],
            buy=[r["player_id"] for r in row["buy"]],
            chip=row["chip"],
            lineup=Lineup.model_validate(row["lineup"]),
        )
        state, checked = transition(state, action, players, rules)
        for field in ("bank_after", "free_transfers_after", "hit", "playing_squad", "permanent_squad"):
            if (
                (set(checked[field]) != set(row[field]))
                if field.endswith("squad")
                else (checked[field] != row[field])
            ):
                raise ValueError(f"Ledger replay mismatch: GW{row['event']} {field}")
    show({"legal": True, "events_replayed": len(plan["ledger"]), "final_bank": state.bank})


@app.command()
def evaluate(prospective: bool = False):
    from .evaluation import evaluate_frozen

    store = Store()
    result = evaluate_frozen(store) if prospective else store.get("evaluation")
    if prospective:
        from .prospective import score_frozen_decisions

        result["policy"] = score_frozen_decisions(store)
    show({k: v for k, v in result.items() if k != "predictions"})


@app.command("freeze")
def freeze_decision(plan_id: str = ""):
    """Archive the actual current recommendation before its deadline for shadow-policy evaluation."""
    from .prospective import freeze

    store = Store()
    show(freeze(store, plan_id or store.get("selected_plan")["plan_id"]))


@app.command("chip-comparison")
def chip_comparison(plan_id: str = "", seconds: float = 30):
    """Re-optimize the whole horizon without each chosen chip under the same football worlds."""
    from .chips import compare_chips

    store = Store()
    show(compare_chips(store, plan_id or store.get("selected_plan")["plan_id"], seconds))


@app.command()
def export(destination: Path = Path("artifacts/runtime/report"), plan_id: str = ""):
    """Export JSON, CSV, Markdown and authoritative deadline ICS."""
    from .reports import export as run

    store = Store()
    show(run(store, store.get("plan", plan_id or store.get("selected_plan")["plan_id"]), destination))


@app.command()
def backup(destination: Path = Path("artifacts/runtime/backup")):
    """Create a portable database and immutable raw/scenario backup."""
    store = Store()
    if destination.resolve().is_relative_to(store.root.resolve()):
        raise typer.BadParameter("Backup destination must be outside the data directory")
    destination.mkdir(parents=True, exist_ok=True)
    store.backup(destination / "state.sqlite")
    for name in ("raw", "scenarios", "models", "normalized", "features"):
        if (store.root / name).exists():
            shutil.copytree(store.root / name, destination / name, dirs_exist_ok=True)
    with closing(sqlite3.connect(destination / "state.sqlite")) as connection:
        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
    show({"backup": str(destination), "database_integrity": integrity})


@app.command()
def serve(host: str = "127.0.0.1", port: int = 8000):
    """Run the private API and production-built React interface."""
    import uvicorn

    from .api import create_app

    if host not in ("127.0.0.1", "::1", "localhost"):
        raise typer.BadParameter("Personal API binds to loopback only")
    uvicorn.run(create_app(), host=host, port=port)


@app.command("managers-refresh")
def manager_refresh():
    """Retrieve all 1,000 current leaders and learn disclosed conditional transfer behavior."""
    from .manager_behavior import collect_top_managers, train_behavior

    store = Store()
    asyncio.run(collect_top_managers(store))
    result = train_behavior(store)
    show(
        {
            k: v
            for k, v in result.items()
            if k not in ("predictions", "models", "ownership", "recent_purchases", "recent_sales")
        }
    )


@app.command("train-transfer-value")
def transfer_value(states: int = 24):
    """Train purged four-week values and test legal random-account transfer decisions."""
    from .horizon import train_horizon
    from .policy_learning import train_policy

    if not 8 <= states <= 128:
        raise typer.BadParameter("Counterfactual states per deadline must be 8–128")
    store = Store()
    train_horizon(store)
    show(train_policy(store, states))


@app.command("analyze-transfers")
def analyze_transfers():
    """Rank legal personal transfer alternatives without replacing the selected plan."""
    from .policy_learning import personalized_analysis

    show(personalized_analysis(Store()))


@app.command("train-complete")
def train_complete(samples: int = 24, refresh: bool = False):
    """Run the complete source, learning, planning and validation workflow."""
    from .workflow import full_training

    if not 4 <= samples <= 128:
        raise typer.BadParameter("Samples 4–128")
    show(full_training(Store(), samples, refresh))


@app.command("train-strategy")
def train_strategy(samples: int = 24):
    from .decision_training import evolve, train_decision_models

    if not 4 <= samples <= 128:
        raise typer.BadParameter("Samples must be 4–128")
    store = Store()
    evolve(store, samples, max_transfers=15)
    show(train_decision_models(store))


@app.command("strategy-analysis")
def strategy_analysis():
    from .decision_runtime import analyze_decisions

    show(analyze_decisions(Store()))


@app.command("timing-analysis")
def timing_analysis_command():
    from .decision_runtime import timing_analysis

    show(timing_analysis(Store()))


@app.command("refine-frontier")
def refine_frontier_command():
    from .decision_runtime import refine_frontier

    show(refine_frontier(Store()))


@app.command("population-analysis")
def population_analysis(per_stratum: int = 16):
    from .population import collect_population, evaluate_population

    store = Store()
    asyncio.run(collect_population(store, per_stratum))
    show(evaluate_population(store))


@app.command("replay-weekly")
def replay_weekly(worlds: int = 4000, seconds: float = 60, end_event: int = 9, current_model: bool = True):
    """Build independent squads through end-event using deadline-pinned inputs."""
    from .replay import run_replay

    if not 1 <= end_event <= 38:
        raise typer.BadParameter("end-event must be between 1 and 38")
    store = Store()
    active = store.get("decision_model") if current_model else {}
    if current_model and active.get("fusion_model_id"):
        raise ValueError(
            "This replay supports the current reference/role family; use its separate fusion policy evaluation for a promoted source family"
        )
    show(
        run_replay(
            store,
            events=list(range(1, end_event + 1)),
            worlds=worlds,
            seconds=seconds,
            participation_model_id=active.get("role_minutes_model_id"),
        )
    )


@app.command("refresh-current")
def refresh_current():
    """Reconcile revealed squad, retrain finalized outcomes and replan the next deadline."""
    from .search_control import search_session
    from .workflow import refresh_cycle

    with search_session(unlimited=True):
        show(refresh_cycle(Store()))


@app.command("benchmark-weekly")
def benchmark_weekly(seconds: float = 60):
    """Compare frozen weekly controls against the reference-only replay."""
    from .replay_benchmarks import compare_weekly_baselines

    result = compare_weekly_baselines(Store(), seconds)
    show({k: result[k] for k in ("id", "reference_total", "comparisons", "limits")})


@app.command("train-consensus")
def train_consensus(seconds: float = 10):
    """Evaluate published-signal fusion on an earlier-season selection/acceptance split."""
    from .consensus import fit_consensus, prepare_inputs

    asyncio.run(prepare_inputs(Store()))
    result = fit_consensus(Store(), seconds)
    show({k: result[k] for k in ("id", "selected", "acceptance", "current_totals", "limits")})


@app.command("compare-consensus")
def compare_consensus(seconds: float = 15):
    """Compare the tested published-signal model on the current real squad."""
    from .consensus import compare_live_consensus

    result = compare_live_consensus(Store(), seconds)
    show({k: result[k] for k in ("id", "event", "historical_gate_passed", "scope", "decisions")})


@app.command("validate-consensus-policy")
def validate_consensus_policy(seconds: float = 10):
    """Replay legal ordinary transfers with bank, gain sharing, FT and hits."""
    from .consensus import validate_continuous_policy

    result = validate_continuous_policy(Store(), seconds)
    show({k: result[k] for k in ("id", "previous_season_totals", "current_totals", "acceptance", "scope")})


@app.command("replay-pipeline")
def replay_pipeline(worlds: int = 4000, seconds: float = 60, current_only: bool = False):
    """Execute the production forecast, full chip-window MIP and continuous account."""
    from .pipeline_jobs import run_pipeline_job

    store = Store()
    market = store.get("market")
    last = max((e["id"] for e in market["events"] if e.get("data_checked")), default=0)
    periods = [(market["season"], list(range(1, last + 1)))] if current_only else None
    result = run_pipeline_job(store, worlds=worlds, seconds=seconds, periods=periods)
    if result.get("future_horizon_model_id"):
        show(result)
        return
    show(
        {
            k: result[k]
            for k in (
                "id",
                "summaries",
                "production_budget",
                "independent_verification",
                "live_pointers_unchanged",
                "limits",
            )
        }
    )


@app.command("freeze-accounts")
def freeze_accounts(seconds: float = 60):
    """Freeze equal-budget prospective accounts before the real deadline."""
    from .shadow_accounts import freeze_shadow_accounts

    result = freeze_shadow_accounts(Store(), seconds)
    show(
        {
            k: result.get(k)
            for k in ("id", "event", "frozen_at", "deadline", "track", "real_account_unchanged", "seed_scope")
        }
    )


@app.command("score-accounts")
def score_accounts():
    """Advance released-deadline finances and score only finalized outcomes."""
    from .shadow_accounts import advance_shadow_accounts

    show(advance_shadow_accounts(Store()))


@app.command("validate-future-policy")
def validate_future_policy(current: bool = False, seconds: int = 60, worlds: int = 4000):
    """Compare the future-only expert through legal full-window chip decisions."""
    from .fixture_horizon import build_data
    from .future_policy_replay import run_future_policy
    from .horizon_trial import fitted
    from .pipeline_jobs import replay_lock

    store = Store()
    options = {}
    with replay_lock(store.root / "pipeline-replay.lock"):
        if current:
            import polars as pl

            market = store.get("market")
            refinement = store.get("horizon_refinement")
            family = refinement["selected"].rsplit("_", 1)[0]
            directory = store.artifact_path(refinement["directory"] + "/protocol.json").parent
            fitted(store, pl.read_parquet(build_data(store)), market["season"] + "-GW01", family, directory)
            last = max(e["id"] for e in market["events"] if e.get("data_checked"))
            options = {"season": market["season"], "events": list(range(1, last + 1))}
        result = run_future_policy(store, seconds=seconds, worlds=worlds, **options)
    show({k: v for k, v in result.items() if k != "weeks"})
