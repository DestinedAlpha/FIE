# Research review · 6 November 2026

This review applies the user's current instruction to retain the statistical/tree models and remove locally trained neural components. Original supplied design documents remain unchanged historical inputs; their technology suggestions do not override that instruction.

## Sources and implementation decisions

| Source reviewed | Useful finding | Result in this system |
|---|---|---|
| [FiveStat methodology](https://www.fivestat.co.uk/methodology), updated September 2026 | Separates team attack/defence, fixture score probabilities, player shares and minutes; evaluates football probabilities out of sample | Retain our separately tested attack/score-process and coherent-world comparisons. Improve participation with the role head below. Do not copy another model's blend/covariance constants without our own acceptance evidence. Their reported performance is not ours. |
| [FPL Core Insights](https://github.com/olbauday/FPL-Core-Insights), README and [data review](https://github.com/olbauday/FPL-Core-Insights/blob/main/DATA_INTEGRATION_REVIEW.md) | Stable player code differs from repository ID; explicit minutes are authoritative; duplicate competitions, incomplete coverage, conflicting match copies and different xG definitions need controls | Existing other-competition ingestion now quarantines conflicting player-match/fixture copies. Positive minutes alone count as physical exposure. The new participation model uses workload alongside news and role; this data is connected to inference. No inference of ninety minutes from missing substitution times. |
| [FPL Optimized](https://fploptimized.com/) | Expected versus actual points, distributions, ownership and hindsight optimization answer different questions | Retain common-world outcome comparisons, expected/net hit payback, actual-return ledgers and hindsight ceilings. Do not present hindsight scores as forecasts. |
| [Open FPL Solver](https://github.com/solioanalytics/open-fpl-solver) | Current home of Sertalp Çay's optimization tools; HiGHS multi-period integer planning | Our solver already uses HiGHS with full-market prices, FT, transfers and chips. Retain visible bounds and legal warm incumbents. A conditional continuation bound is not a global bound over all first actions. |
| [FPL Research](https://www.fplresearch.com/) | Historical manager qualification differs from a current-rank leaderboard | Retain separate prior-qualified and current top-1,000 cohorts. Earlier picks/transfers inform manager behavior; current rank cannot be a historical elite label. Their future moves remain probabilistic scenarios. |
| [Elevenify Fantasy Frameworks](https://www.elevenify.com/p/fantasy-frameworks) | Understand model assumptions, probability scales and information that would change a decision | Preserve dated evidence, source sensitivities, late recourse and uncertainty. Correlated forecasts are not independent votes. Pundit agreement alone is not an expected-points increase. |
| [vaastav historical archive](https://github.com/vaastav/Fantasy-Premier-League), [Understat](https://understat.com/) | Multi-season outcomes and attacking evidence complement current FPL data | Already ingested with stable identities and chronological lagging; enriched statistics feed the tested source/future trees. Preserve provider definitions and missingness. |
| FBref / [2026 removal report](https://www.sportseconomics.org/sports-economics/fbref-com-data-removal) | The screenshot's Opta advice is outdated: the advanced-data agreement ended in January 2026 | Do not create an unavailable advanced-FBref dependency. The Sports Reference announcement URL returned 403 during this review; current reporting corroborates the change. |
| r/fplAnalytics [expected-points methods](https://www.reddit.com/r/fplAnalytics/comments/1vioe4q/i_made_an_expected_points_model_here_is_how_ive/) and [follow-up](https://www.reddit.com/r/fplAnalytics/comments/1vkqtss/i_made_an_expected_points_model_part_2_does_it/) | Minutes/DefCon/bonus require explicit distributions; descriptive expected returns per appearance are not automatically prospective predictions | Retain minute bands, rule-aware DefCon and match-wide physical bonus comparisons. Do not substitute a filtered retrospective season fit for walk-forward prediction validation or train on anonymous opinions. |

Core Insights permits use of its data and requests attribution; this project credits olbauday. No foreign repository scripts were executed or copied. Its PL detailed shots, positions and Elo are not all added indiscriminately: overlapping shot data and retrospectively supplied fields need distinct definitions, causal availability and demonstrated incremental value. Existing official and Understat advanced features remain connected to tested trees.

## Implemented participation improvement

The new LightGBM classifier uses 57 inputs: the existing 26 numerical features, nine dated role features, thirteen official news/availability features, seven workload features and two coverage indicators. Role includes archived season starts/minutes and recent starts from prior matches. Bootstrap archive schema 3 preserves the additional fields from the original hash-pinned pre-deadline files. Historical joins use stable player codes.

Eight-deadline expanding tests reserve eight earlier deadlines for probability calibration. The mixture weight is selected only on 2024/25 GW1–19. Acceptance is GW20–38 (14,492 player-fixtures); independent replication is all 2025/26 (29,644). Current-season outcomes do not choose the configuration. Confidence intervals resample whole deadlines. Both overall point error and regular-starter error must improve; all four position cohorts are disclosed.

| Held-out period | Minutes Brier, previous → role-aware | Point MSE, previous → role-aware |
|---|---:|---:|
| 2024/25 GW20–38 | 0.308270 → 0.298704 | 3.340446 → 3.310779 |
| 2025/26 | 0.290465 → 0.278451 | 3.602296 → 3.544659 |

Both point-MSE deadline-block intervals exclude zero: [-0.04363, -0.01424] and [-0.08171, -0.04015]. The participation Brier intervals also exclude zero. These are forecast improvements, not proof of a particular transfer gain or future rank. [Executed metrics and protocol](../artifacts/evaluations/role_minutes_validation.json).

Immediate forecasts consume the accepted participation probabilities without multiplying published injury chance twice. Explicit availability scenarios and served suspensions retain their baseline scenario path. The previously accepted distant-fixture expert remains separately bound. Completed new labels trigger refitting; an upcoming gameweek never supplies its own labels.

## Cleanup and data fixes

Removed local tensor architectures, inference, training commands/options, dependency extra/index, CI job, weights and controls. The environment no longer contains PyTorch. Existing-install migration deletes only retired tensor weights inside its model directory, preserves account/keys/tree weights, removes the retired action input from historical training rows without altering outcomes, and refits manager-choice and action-critic trees. Historical content-addressed receipts are retained as provenance, not executable candidates.

Unused substitutes no longer reset physical rest or count as played matches. Older frozen models explicitly retain the legacy workload transform, protecting train/serve compatibility. The latest Core Insights refresh retrieved 180/180 files, accepted 3,451 player-match records and quarantined 16 conflicting duplicate player-match groups; other identity/date rejections remain visible in coverage.

The transfer investigation compares the actual synchronized squad against rolling and named alternatives on the same fresh forecast. Player names never enter a forced transfer rule. Better participation accuracy cannot by itself settle Van Dijk versus a midfielder: legal lineup displacement, captaincy, bank, transfer opportunity and the continuation search all affect that decision. Current recommendation evidence is recorded separately from these historical forecast tests.

The planner now filters reusable plans by account before limiting the cache; unrelated branch activity cannot evict stronger candidates. Refreshed-market continuations are replayed against current prices and constraints and ranked on current forecasts. Candidates generated with a later information cutoff cannot seed an earlier search. An unaffordable older plan is still rejected, even if its old displayed score was higher.

The fresh chip calendar evaluated all 20 available first-half chip dates. Its current Free Hit route gained only about 1.19 modeled points over a 300-second ordinary-transfer control, whose additive search remained unresolved by about 11.72 points. That small difference cannot establish the value of spending the chip now. Optional current chips now use the same evidence standard as paid transfers, against a control at the same hit budget that preserves later chip use. Committed, explicitly fixed and expiring current entitlements are handled separately. The selected current action retains Free Hit and Bench Boost, uses the available free transfer and keeps Calafiori. These guards are decision safeguards; they are not measured future-rank guarantees.


## 7 November follow-up: sources and confirmed gaps

The newly supplied comprehensive checklist was reviewed against the existing 178-finding audit and retained experiments. Its suggestions are research candidates, not instructions to replace a validated model with a more complicated one. The original audit and historical scorecards remain unchanged.

FiveStat's [methodology page](https://www.fivestat.co.uk/methodology) was fetched again successfully. The September 2026 revision separates team attack/defence, home advantage, a scoreline matrix, player goal/assist shares, minutes, and walk-forward football evaluation. Its over/under and clean-sheet markets come from the same score distribution. FIE already tests attack/defence and score-process alternatives; its primary conditional-points trees use team/opponent strength, lagged xG/xA and playing exposure. This is not an exact replica of FiveStat. Their 0.30 recency weight, 70/30 player-share blend and shared-score covariance are not universal football constants and were not copied into accepted weights.

The existing FIE score-process challenger did not clear its deadline-block interval: strength NLL difference [-0.06245, 0.00307]. Its selected Dixon–Coles dependence was worse on the held-out period, so independence remained adopted. The existing temporal study did not establish a beneficial finishing correction or decay; decay 1.0 and no finishing correction remain accepted. Repeating those experiments or forcing a Gabriel-specific adjustment would not add evidence. The separately accepted role head and future-fixture expert retain their original gates.

The latest [Core Insights integration review](https://github.com/olbauday/FPL-Core-Insights/blob/main/DATA_INTEGRATION_REVIEW.md) and [Open FPL Solver README](https://github.com/solioanalytics/open-fpl-solver/blob/main/README.md) were reviewed again. Core Insights distinguishes its shot-model xG from match-summary xG, reports incomplete non-PL coverage, quarantined identities/timestamps and sparse weather/travel fields, and does not provide its collection scripts or original API provenance. These are reasons to preserve provider boundaries and the existing workload quarantine, not to invent tracking data or treat post-match positions as pre-match knowledge. The StatsBomb open-data catalogue was also fetched: its 80 competition/season entries include Premier League 2015/16 and 2003/04, not a complete current Premier League replacement. The current r/fplAnalytics JSON listing returned HTTP 403; no restriction was bypassed. Earlier reviewed community methods remain qualitative research. No new paid or inaccessible feed was introduced.

Understat's league, league-page and match routes returned HTTP 200 HTML error pages without usable embedded datasets during this review. FIE now reports that response clearly. League/match schemas and finite statistics are checked before a response can become a verified cache entry. Bad cached shapes are rejected; a partial successful refresh merges by season/player-code/fixture and preserves older verified matches. The fix does not claim to restore a provider that is presently unavailable or erase unresolved joins.

The active data connections remain explicit: 26 immediate numerical features; 57 role/minutes features; 138 future-fixture features; manager choices for rival behavior and scenarios; source-grounded news for named sensitivities. Shot channels and broad advanced-statistic candidates are research/sensitivity inputs where their production gate failed. Collected information is not automatically independent predictive evidence, and an unused candidate does not justify a hidden numerical boost.

### Authentic news checks and the evidence upgrade

A fixed corpus contains 16 authentic excerpts from seven previously archived club/specialist articles: absences, training, injury doubt, suspension and unrelated scoring statistics. Labels were frozen before requests. The corpus selection prose says five reports; its actual distinct-URL count is seven, as reported in the executed results. This provenance correction does not change any label or quotation.

The initial [results](../artifacts/evaluations/authentic_extraction_initial.json) were Groq 13/16 and Gemini 11/16; Gemini's unsupported-quote batch was rejected in full. General production guards now preserve training as reported activity, distinguish doubt from a confirmed absence, reject reversed availability polarity, and accept explicit “remains out” reports. Cached evidence is versioned and revalidated on upgrade; source bodies supplied with manual claims are retained for that audit. Missing legacy origin hashes no longer crash the migration.

On the same inspected corpus, [the repeated check](../artifacts/evaluations/authentic_extraction.json) scored Groq 16/16 and Gemini 11/16, with the unsupported Gemini batch again rejected. This is a regression check after fixing known cases, not new held-out accuracy or improved football returns. Neither prompt nor provider was promoted from this small study; Groq was already the selected route, with Gemini remaining an optional validated-source fallback. No historical benchmark claim enters live evidence and no numeric model weights changed.

The existing-install update exposes the bundled completed benchmark without importing its historical accounts into the user database. A locally executed replay takes precedence. Incomplete bundled reports are rejected.


### Current-reference scoring experiments

The earlier rejected statistics/bias receipts used role-v2. Both full experiments were rerun against the actual role-v3 participation configuration and current pinned context, preserving the old receipts byte-for-byte. No current-season return chose a family or weight. Selection remains 2024/25 GW1–19; acceptance is GW20–38 and replication is all 2025/26. Eight earlier deadlines are reserved for calibration inside expanding folds.

| Replication, 2025/26 | Reference RMSE | Candidate RMSE | Reference captain diagnostic | Candidate captain diagnostic | Result |
|---|---:|---:|---:|---:|---|
| Multi-window form/advanced statistics, selected XGBoost mixture | 1.882673 | 1.882381 | 262 | 222 | Rejected: interval includes zero, premium error increases, captain diagnostic deteriorates |
| Earlier-error correction, selected decay 0.8 / shrinkage 32 | 1.882673 | 1.883583 | 262 | 243 | Rejected: overall/regular error and captain diagnostic deteriorate |

These captain totals choose a player from the whole eligible market each deadline; they are not team totals or proof that a player was affordable in a particular account. [Statistics results](../artifacts/evaluations/immediate_points_validation_v3.json) · [Bias results](../artifacts/evaluations/online_calibration_validation_v3.json). The accepted numerical model ID and all production weights remained unchanged.

An independent descriptive check of the retained role-v3 predictions found regular-defender replication RMSE 3.02759 → 3.00960 and bias +0.05153 points/player-fixture. Regular-forward RMSE and several MAE cohorts do not improve. These already-inspected subgroup diagnostics neither justify a universal positional boost nor establish superiority on every metric.

The frozen GW6 registry and earlier completed histories agree: Fernandes' five returns were 2, 23, 2, 2, 2; Haaland's were 2, 13, 9, 9, 6. Fernandes' published form was 2.0 and season PPG 6.2; Haaland's were 7.5 and 7.8. The normal served composition, using only pre-deadline inputs, estimated 6.69942 versus 5.90306 immediate points. That identifies a forecast disagreement rather than a captain-selector defect. The historical mean contains the outlier, but it is not a causal explanation of every nonlinear-tree contribution. Rejected recent-form experiments already consume shorter windows; changing the head merely to fit this player or the inspected nine-week result would bypass acceptance.

Public replay downloads include the actual sealed action bodies and player-name mappings, not just local build-machine paths. The dashboard omits those larger bodies while its download retains them. Uncertainty resamples contiguous three-week blocks because continuous accounts are coupled across deadlines; intervals from a short inspected reconstruction remain exploratory, not a claim of future superiority.

### Completed combined-model continuous replay

This new reconstruction starts all three policies from the same £100m GW1 account. Each deadline uses pinned registries and strictly earlier fitted/calibrated heads. The current combined family includes role-v3, conditional points and the future-fixture expert; the reference omits only the role head. The simpler control plans one week with the same immediate forecast and no chips. Account prices, selling lots, bank, free transfers, actual autosubs/captaincy and hits carry forward. The actual user account is never substituted for this seed.

| GW | Combined net | Future reference net | One-week / no chips net |
|---|---:|---:|---:|
| 1 | 41 | 41 | 48 |
| 2 | 94 | 93 | 84 |
| 3 | 36 | 36 | 50 |
| 4 | 61 | 61 | 71 |
| 5 | 53 | 53 | 56 |
| 6 | 30 | 29 | 41 |
| 7 | 49 | 49 | 54 |
| 8 | 86 | 86 | 46 |
| 9 | 60 | 62 | 49 |
| **Total** | **510** | **510** | **499** |

All 27 actions passed independent scoring, continuity, cutoff and model-checksum verification. These runs incurred no hits and retained their chips through GW9. The main policy planned through the first-half chip window, not just the scored nine weeks. All policies used seed 11 and 4,000 worlds; primary research MIPs used 60 seconds, with the existing production selection controls allowed their separate 60–300-second comparisons. This is not equal total CPU time and does not certify the unlimited live solve. Full-window continuation leaves value beyond the scored interval.

The combined-minus-reference weekly-difference exploratory three-week block interval is [-0.55556, 0.33333]. The forecasts were not retuned on these results. The tie does not invalidate the role head's earlier forecast-calibration gains, but it does not establish a continuous-policy points gain. Consistent 550+ points, prospective rank superiority, and a globally optimal strategy under unknown outcomes remain unproven. The earlier 575 fresh-team and 1,202 older-policy scorecards retain their different protocols. [Executed results and actual frozen actions](../artifacts/evaluations/composed_policy_replay.json).

The official account refresh independently synchronized the revealed GW10 transfers and advanced planning to GW11. The expired GW10 proposal cannot be executed as current advice. Retraining on partial GW10 labels was not performed; finalized outcomes through GW9 remain the accepted fit/calibration boundary. Ordinary retraining after new finalized outcomes remains automatic.


## Production readiness · 0.14.1

The final local release checks actually passed: Ruff, formatting, mypy, **272 backend tests**, frontend build, **3 frontend tests** and **22 desktop/mobile browser journeys**, with no skipped tests or browser failures. Browser checks use a consistent isolated historical planning fixture and pinned test clock; they do not submit real FPL transfers or establish prospective performance. A separate API smoke check used an existing database with no combined-replay object and successfully served all nine bundled decisions and 27 actions while keeping the dashboard response compact.

Windows and Linux CI passed, including the Windows PowerShell launcher and compressed-database smoke path. The numerical replay itself ran on Linux CPU. The installer was also exercised over exact v0.14 files against a copy of the actual 1.07 GB database: account, market, forecast, selected-plan and numerical-model IDs were preserved; all seven accepted base/role/future weight files retained their checksums and loaded through the installed code. A sandbox private key file was preserved; real API keys were not copied. Backup/rollback and failure-path regressions are included in the backend suite.

The release is verified as a local application with the confirmed ingestion, evidence, update and UI gaps addressed. The original 178-item register remains preserved; its scientific limitations are not relabelled as fixed bugs. The delivery record extends it with the current reproductions, studies and evidence: [release and issue ledger](https://github.com/DestinedAlpha/FIE/blob/v0.14.1/artifacts/evaluations/release_0_14_1.json).

Accepted numerical weights remain unchanged because neither new scoring candidate passed. The combined nine-week continuous strategy is now measured, with its exact limits stated above. It has no proven 550+ consistency, protected prospective rank advantage, or guarantee of globally optimal future outcomes. Unlimited live search still solves an additive forecast approximation; the bounded reconstruction does not certify that entire live policy. Understat remains externally unavailable during the source probe, and unresolved joins remain quarantined. These are explicit evidence limits, rather than silent fabricated data or unfinished production branches.

Existing-install updates preserve private accounts, keys and accepted models. The user should recompute from fresh data after the elapsed deadline; expired GW10 suggestions remain invalid. New finalized outcomes trigger the existing chronological refit process. No retraining was performed using unfinished GW10 targets. Obsolete UI/test scratch was removed; raw sources, backups, accepted weights and sealed research decisions were retained.
